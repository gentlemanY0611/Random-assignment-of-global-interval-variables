import React, { useEffect, useState } from "react";
import {
  Extension,
  extension,
  method,
  settings,
  useExtensionContext,
  type ExtensionContext,
  type SettingsBuilder,
} from "@avg-studio/sdk";
// 提示条默认背景图（随扩展打包内联；可被手动替换）
import hintBgUrl from "./assets/hint-bg.png";

/* ------------------------------------------------------------------ *
 * 全局间期变量随机赋值2.0（periodic-random-decay-2.0）
 *
 * 功能：注册一条规则后，每当「自变量」推进达到设定的间隔数，
 *       自动把「因变量」随机增加或减少 [下限, 上限] 区间内的一个整数。
 *       - 全局自动触发：插件在引擎启动时挂载全局监听，只要自变量
 *         发生变化（无论来自哪个选项、章节或剧情）都会自动结算，
 *         不受选项等其他因素影响。
 *       - 剧本选项卡中可以直接选择变量：本扩展的剧本方法使用
 *         type: "variable" 参数，在「调用扩展方法」Block 的属性面板里
 *         会出现变量下拉选择器。
 * ------------------------------------------------------------------ */

/* ----------------------------- 数据结构 ----------------------------- */

/** 规则主体（不含数据库生成 id） */
type DecayRuleData = {
  /** 自变量名：表示推进变化的数值变量（如游戏日） */
  dayVariable: string;
  /** 因变量名：需要被周期赋值的数值 */
  targetVariable: string;
  /** 自变量变化数（间隔数）：每经过 N 个间隔结算一次 */
  interval: number;
  /** 随机变化下限（含） */
  minDecrease: number;
  /** 随机变化上限（含） */
  maxDecrease: number;
  /** 上次结算时的自变量值（用于判断是否到期） */
  lastAppliedDay: number;
  /** 变化时是否在游戏中显示提示 */
  showHint: boolean;
  /** 方向：decrease=减少，increase=增加 */
  mode: "decrease" | "increase";
};

/** 数据库中的完整规则记录 */
type DecayRule = DecayRuleData & { id: string };

/** 规则集合的最小操作面（与 ctx.database.collection 返回类型兼容） */
interface RulesCollection {
  find(filter?: unknown): Promise<unknown[]>;
  insertOne(data: Record<string, unknown>): Promise<{ id: string }>;
  updateOne(
    filter: Record<string, unknown>,
    update: Record<string, unknown>,
  ): Promise<unknown>;
  deleteOne(filter: Record<string, unknown>): Promise<unknown>;
}

/* ----------------------------- 工具函数 ----------------------------- */

/** 取 [min, max] 闭区间内的随机整数；非法范围自动纠正为 [0, 大] */
function randomInt(min: number, max: number): number {
  const lo = Math.max(0, Math.min(min, max));
  const hi = Math.max(0, Math.max(min, max));
  if (hi === 0) return 0;
  return Math.floor(Math.random() * (hi - lo + 1)) + lo;
}

/** 获取规则集合（规则持久化在项目数据集合中，随存档保存） */
function rulesCollection(ctx: ExtensionContext): RulesCollection {
  return ctx.database.collection("rules") as unknown as RulesCollection;
}

/* ------------------- 全局结算（核心逻辑，串行执行） ------------------ */

/**
 * 串行队列：variable:changed 可能在一瞬间被触发多次
 * （例如结算时写入因变量也会触发事件），必须保证
 * 结算过程不重叠，否则会出现重复变化。
 */
let tickQueue: Promise<void> = Promise.resolve();

function enqueueTick(ctx: ExtensionContext): void {
  tickQueue = tickQueue
    .then(() => processAllRules(ctx))
    .catch((err) => console.warn("[全局间期变量随机赋值2.0]", err));
}

/** 遍历全部规则，逐条结算 */
async function processAllRules(ctx: ExtensionContext): Promise<void> {
  const rules = rulesCollection(ctx);
  const all = ((await rules.find({})) ?? []) as DecayRule[];
  for (const rule of all) {
    await processRule(ctx, rules, rule);
  }
}

/** 结算单条规则 */
async function processRule(
  ctx: ExtensionContext,
  rules: RulesCollection,
  rule: DecayRule,
): Promise<void> {
  const day = ctx.variables.get<number>(rule.dayVariable);

  // 自变量还不是数值（未初始化 / 声明类型不对 / 数据损坏）→ 跳过并提示
  if (typeof day !== "number" || !Number.isFinite(day)) {
    console.warn(
      `[全局间期变量随机赋值2.0] 自变量「${rule.dayVariable}」当前不是有效数值，已跳过本次结算。`,
    );
    return;
  }

  // 防御：数据集合被手工编辑成非法值时仍能正常结算
  const interval = Math.max(1, Math.floor(rule.interval) || 1);
  const minD = Number.isFinite(rule.minDecrease) ? rule.minDecrease : 0;
  const maxD = Number.isFinite(rule.maxDecrease) ? rule.maxDecrease : 0;

  // 天数回退（新游戏、返回入口、读更早存档等）→ 立即把基线持久化为当前天，
  // 重新起算；否则旧基线残留在数据中会导致后续永远不再结算。
  let last = rule.lastAppliedDay;
  if (!Number.isFinite(last)) last = day;
  if (day < last) {
    last = day;
    await rules.updateOne(
      { id: rule.id },
      { $set: { lastAppliedDay: day } },
    );
    return;
  }

  const elapsed = day - last;
  if (elapsed < interval) return;

  // 扩展设置里的总开关：关闭时只“追平”间隔数、不变化，
  // 避免重新开启后一次性把之前所有周期全部补算。
  const enabled = ctx.settings.get<boolean>("enabled") ?? true;
  if (!enabled) {
    await rules.updateOne(
      { id: rule.id },
      { $set: { lastAppliedDay: day } },
    );
    return;
  }

  // 计算应结算的完整周期数（支持一次跳过多个间隔/多天）
  const times = Math.floor(elapsed / interval);
  let delta = 0;
  for (let i = 0; i < times; i++) {
    delta += randomInt(minD, maxD);
  }

  const mode = rule.mode === "increase" ? "increase" : "decrease";
  const current = ctx.variables.get<number>(rule.targetVariable);
  // 减少方向最低扣到 0；增加方向不设上限
  const next = mode === "increase"
    ? (current ?? 0) + delta
    : Math.max(0, (current ?? 0) - delta);
  ctx.variables.set(rule.targetVariable, next);

  // 写入因变量会再次触发 variable:changed → 队列中会再跑一次结算；
  // 此时上次结算日已推进，elapsed < interval，不会重复结算。
  await rules.updateOne(
    { id: rule.id },
    { $set: { lastAppliedDay: last + times * interval } },
  );

  const actionText = mode === "increase" ? "增加" : "减少";
  console.log(
    `[全局间期变量随机赋值2.0] ${rule.targetVariable}：${current ?? 0} → ${next}` +
      `（经过 ${times} 个间隔，共随机${actionText} ${delta}；自变量 ${last} → ${last + times * interval}）`,
  );

  if (rule.showHint) {
    void ctx.ui.show("periodic-hint-ui", {
      message: `${rule.targetVariable} ${actionText}了 ${delta} 点（当前 ${next}）`,
      actionText,
    });
  }
}

/* ------------------------------ 扩展本体 ----------------------------- */

@extension({
  id: "periodic-decay",
  label: "全局间期变量随机赋值2.0",
  description:
    "每经过指定间隔数，自动把因变量的值随机增加或减少一个区间内的数值；全局自动触发，不受选项影响，剧本中可直接选择变量。",
})
export class PeriodicDecay extends Extension {
  /** 项目级设置：总开关 + 自定义提示条字体 + 文字颜色 */
  static settings = settings((s: SettingsBuilder) => ({
    enabled: s.boolean("全局变量间期随机赋值").default(true),
    hintBackground: s
      .asset("提示条背景图（可选）")
      .accepts("image")
      .describe(
        "在素材选择器里选择引擎中已导入的图片（如资产-背景图）作为提示条背景；不设置时使用插件自带默认图（也可手动拖入 src/assets/hint-bg.png 替换后重新构建）。规格：横向宽图，推荐 1024×512（2:1）或更宽，PNG 透明底最佳，重要内容放画面中央（左右边缘会被等比裁切）。",
      ),
    hintFontAsset: s
      .asset("提示条字体（可选）")
      .accepts("any")
      .describe(
        "填写或选择已下载/导入的字体（填字体名列表如 “'Source Han Serif SC', sans-serif”，或以 http/data: 开头的字体文件地址）；不设置时跟随游戏界面默认字体。",
      ),
    hintColor: s
      .color("提示条文字颜色")
      .default("#FFFFFF")
      .describe("提示条文字的颜色，默认白色。"),
  }));

  /**
   * 模块级全局钩子：引擎启动时注册一次。
   * 监听所有运行时变量变化，只要「自变量」推进到结算点，
   * 无论玩家走到哪个选项分支，都会自动变化。
   */
  static onRegister(ctx: ExtensionContext): void {
    ctx.subscribe("variable:changed", () => {
      enqueueTick(ctx);
    });
    console.log("[全局间期变量随机赋值2.0] 全局监听已挂载。");
  }

  /** 注册一条全局间期随机赋值规则（可减可加） */
  static registerDecay = method({
    title: "注册全局间期随机赋值",
    description:
      "注册一条规则：从当前自变量（游戏日）的数值起算，每经过 N 个间隔数，因变量（目标数值）的值自动随机增加或减少 [下限, 上限] 区间内的一个整数。规则全局自动触发，不受选项影响。",
    schema: {
      dayVariable: {
        type: "variable",
        label: "自变量",
        required: true,
      },
      targetVariable: {
        type: "variable",
        label: "因变量",
        required: true,
      },
      mode: {
        type: "enum",
        label: "操作方向",
        options: [
          { value: "decrease", label: "减少" },
          { value: "increase", label: "增加" },
        ],
        default: "decrease",
        required: true,
      },
      interval: {
        type: "number",
        label: "自变量变化数（间隔数）",
        min: 0,
        max: 999999,
        step: 1,
        default: 7,
        required: true,
      },
      minDecrease: {
        type: "number",
        label: "随机变化下限",
        min: 0,
        max: 999999,
        step: 1,
        default: 1,
        required: true,
      },
      maxDecrease: {
        type: "number",
        label: "随机变化上限",
        min: 0,
        max: 999999,
        step: 1,
        default: 5,
        required: true,
      },
      showHint: {
        type: "boolean",
        label: "变化时在游戏中显示提示",
        default: true,
      },
    },
    async run(
      ctx: ExtensionContext,
      params: {
        dayVariable: string;
        targetVariable: string;
        mode: "decrease" | "increase";
        interval: number;
        minDecrease: number;
        maxDecrease: number;
        showHint: boolean;
      },
    ): Promise<void> {
      const {
        dayVariable,
        targetVariable,
        mode,
        interval,
        minDecrease,
        maxDecrease,
        showHint,
      } = params;

      if (minDecrease > maxDecrease) {
        console.warn(
          `[全局间期变量随机赋值2.0] 下限(${minDecrease})大于上限(${maxDecrease})，运行时会自动交换处理。`,
        );
      }

      const startDay = ctx.variables.get<number>(dayVariable) ?? 0;
      const rules = rulesCollection(ctx);
      await rules.insertOne({
        dayVariable,
        targetVariable,
        mode,
        interval: Math.max(1, Math.floor(interval)),
        minDecrease,
        maxDecrease,
        lastAppliedDay: startDay,
        showHint,
      });

      const actionText = mode === "increase" ? "增加" : "减少";
      console.log(
        `[全局间期变量随机赋值2.0] 已注册规则：每 ${interval} 个间隔数，` +
          `「${targetVariable}」随机${actionText} ${minDecrease}~${maxDecrease} 点` +
          `（从当前自变量 ${startDay} 起算）`,
      );
    },
  });

  /** 按“自变量 + 因变量”移除已注册的规则 */
  static removeDecay = method({
    title: "移除全局间期随机赋值",
    description:
      "按「自变量 + 因变量」删除已注册的规则，删除后不再自动变化。",
    schema: {
      dayVariable: {
        type: "variable",
        label: "自变量",
        required: true,
      },
      targetVariable: {
        type: "variable",
        label: "因变量",
        required: true,
      },
    },
    async run(
      ctx: ExtensionContext,
      params: { dayVariable: string; targetVariable: string },
    ): Promise<void> {
      const rules = rulesCollection(ctx);
      const matches = ((await rules.find({
        dayVariable: params.dayVariable,
        targetVariable: params.targetVariable,
      })) ?? []) as DecayRule[];
      for (const rule of matches) {
        await rules.deleteOne({ id: rule.id });
      }
      console.log(
        `[全局间期变量随机赋值2.0] 已移除 ${matches.length} 条规则` +
          `（${params.dayVariable} × ${params.targetVariable}）`,
      );
    },
  });

  /** 清空当前存档中的全部规则 */
  static clearAllDecay = method({
    title: "清空全部间期随机赋值规则",
    description: "删除当前存档中注册的全部间期随机赋值规则。",
    async run(ctx: ExtensionContext): Promise<void> {
      const rules = rulesCollection(ctx);
      const all = ((await rules.find({})) ?? []) as DecayRule[];
      for (const rule of all) {
        await rules.deleteOne({ id: rule.id });
      }
      console.log(
        `[全局间期变量随机赋值2.0] 已清空全部 ${all.length} 条规则`,
      );
    },
  });

  /** 诊断方法：在游戏中弹出当前状态，方便排查问题 */
  static diagnose = method({
    title: "诊断：打印当前状态",
    description:
      "在游戏画面顶部弹出当前规则数量、每条规则详情、自变量和因变量的当前值。用于排查为什么变化不生效。",
    async run(ctx: ExtensionContext): Promise<void> {
      const lines: string[] = [];
      lines.push("=== 诊断 ===");

      try {
        const rules = rulesCollection(ctx);
        const all = ((await rules.find({})) ?? []) as DecayRule[];
        lines.push(`规则总数：${all.length}`);
        for (let i = 0; i < all.length; i++) {
          const r = all[i];
          const day = ctx.variables.get<number>(r.dayVariable);
          const target = ctx.variables.get<number>(r.targetVariable);
          lines.push(
            `#${i + 1} 自变量=${r.dayVariable}(${day}) 因变量=${r.targetVariable}(${target}) ` +
            `${r.mode === "increase" ? "加" : "减"} 间隔=${r.interval} ${r.minDecrease}~${r.maxDecrease} 上次=${r.lastAppliedDay}`,
          );
        }
      } catch (e) {
        lines.push(`读取规则失败：${String(e)}`);
      }

      console.log("[诊断]\n" + lines.join("\n"));
      void ctx.ui.show("periodic-diag-ui", {
        lines,
      });
    },
  });
}

/* ------------------- 自定义提示 / 诊断界面 ------------------- */

/** 从素材值里尽量提取可显示的地址（兼容字符串与对象两种形态） */
const extractAssetUrl = (v: unknown): string | undefined => {
  if (typeof v === "string") {
    const t = v.trim();
    return t.length > 0 ? t : undefined;
  }
  if (v && typeof v === "object") {
    const o = v as Record<string, unknown>;
    for (const k of ["url", "uri", "src", "path", "source", "assetUrl"]) {
      const val = o[k];
      if (typeof val === "string" && val.trim().length > 0) return val.trim();
    }
    for (const k of ["value", "id"]) {
      const val = o[k];
      if (typeof val === "string" && val.trim().length > 0) return val.trim();
    }
  }
  return undefined;
};

/**
 * 把素材设置值解析为可显示地址。
 * SDK 真实契约：素材设置值 = 素材 URI；ctx.asset.resolve(uri) → AssetRef（含可访问地址）。
 * 优先走 resolve，再对返回对象做常见字段提取；resolve 不可用/失败时退回原始值直接尝试。
 */
const resolveAssetUrl = (
  ctx: ExtensionContext,
  raw: unknown,
): string | undefined => {
  const direct = extractAssetUrl(raw);
  const assetApi = (ctx as unknown as Record<string, unknown>)["asset"] as
    | Record<string, unknown>
    | undefined;
  const resolveFn =
    assetApi && typeof assetApi["resolve"] === "function"
      ? (assetApi["resolve"] as (u: unknown) => unknown)
      : undefined;
  if (resolveFn) {
    try {
      const ref = resolveFn(direct ?? raw);
      console.log(
        "[全局间期变量随机赋值2.0] ctx.asset.resolve 结果：",
        JSON.stringify(ref),
      );
      return extractAssetUrl(ref) ?? direct ?? undefined;
    } catch (err) {
      console.warn(
        "[全局间期变量随机赋值2.0] ctx.asset.resolve 解析失败：",
        err,
      );
      return direct ?? undefined;
    }
  }
  return direct ?? undefined;
};

type HintProps = { message?: string; actionText?: string };

/**
 * 数值变化提示：顶部通栏提示条。
 * 背景：扩展设置里选的引擎素材 > 插件打包默认图（hint-bg.png）。
 * 文字：可选自定义字体 + 颜色。约 2.5 秒后自动关闭。
 */
const HintOverlay: React.FC<HintProps> = ({ message, actionText }) => {
  const ctx = useExtensionContext();
  const [fontReady, setFontReady] = useState(false);
  const [resolvedBg, setResolvedBg] = useState<string | undefined>(undefined);

  // 读取创作者在扩展设置里选的提示条背景图、字体素材与文字颜色
  const rawBg = ctx.settings.cross.get<unknown>(
    "periodic-decay",
    "hintBackground",
  );
  const fontAsset = ctx.settings.cross.get<string>(
    "periodic-decay",
    "hintFontAsset",
  );
  const hintColor = ctx.settings.cross.get<string>(
    "periodic-decay",
    "hintColor",
  );

  // 解析提示条背景素材为可显示 URL；未设置时回退插件打包默认图
  useEffect(() => {
    if (!rawBg) return;
    console.log(
      "[全局间期变量随机赋值2.0] 自定义提示条背景原始值：",
      JSON.stringify(rawBg),
    );
    const u = resolveAssetUrl(ctx, rawBg);
    if (u) setResolvedBg(u);
  }, [ctx, rawBg]);

  // 调试用：打印设置里的字体值形态，便于确认是否需要额外解析
  useEffect(() => {
    if (fontAsset) {
      console.log(
        "[全局间期变量随机赋值2.0] 自定义提示条字体值：",
        fontAsset,
      );
    }
  }, [fontAsset]);

  // 判断素材值是否是可直接加载的 URL（http/https/data/blob）
  const isUrlLike = (v: string): boolean =>
    /^(https?:|data:|blob:)/i.test(v.trim());

  // 动态加载所选字体：
  // - 值是 URL（字体文件地址）→ 用 FontFace 动态注册后使用
  // - 值不是 URL（直接填的字体名 / font-family 列表）→ 无需加载，直接作为 fontFamily
  useEffect(() => {
    const fontVal = fontAsset?.trim();
    if (!fontVal) return;
    if (!isUrlLike(fontVal)) return;
    const face = new FontFace("PeriodicHintFont", `url(${fontVal})`);
    face
      .load()
      .then((loaded) => {
        document.fonts.add(loaded);
        setFontReady(true);
      })
      .catch((err) =>
        console.warn("[全局间期变量随机赋值2.0] 提示条字体加载失败：", err),
      );
  }, [fontAsset]);

  // 背景：优先用扩展设置里选的引擎素材（经解析后的 URL）；解析不到时用打包默认图
  const bgSrc = resolvedBg ?? hintBgUrl;

  // 字体显示逻辑：
  // - URL 且加载成功 → 使用动态注册的 PeriodicHintFont
  // - 非 URL（字体名/font-family 列表）→ 直接使用该值
  // - 未设置 → 跟随游戏界面默认字体
  const fontVal = fontAsset?.trim();
  const fontSrc = fontVal
    ? isUrlLike(fontVal)
      ? fontReady
        ? "PeriodicHintFont"
        : undefined
      : fontVal
    : undefined;

  useEffect(() => {
    const timer = setTimeout(() => {
      void ctx.ui.hide("periodic-hint-ui");
    }, 2500);
    return () => clearTimeout(timer);
  }, [ctx, message]);

  if (!message) return null;

  // 文字颜色：优先用扩展设置里的「提示条文字颜色」，未设置时默认白色
  const textColor = hintColor && hintColor.trim().length > 0 ? hintColor.trim() : "#FFFFFF";

  return (
    <div
      style={{
        position: "absolute",
        top: 20,
        left: "50%",
        transform: "translateX(-50%)",
        zIndex: 9999,
        width: "min(720px, 88vw)",
        height: 68,
        backgroundImage: `url(${bgSrc})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        pointerEvents: "none",
        filter: "drop-shadow(0 6px 16px rgba(0, 0, 0, 0.45))",
      }}
    >
      <span
        style={{
          fontSize: 18,
          fontWeight: 700,
          color: textColor,
          textShadow: "0 2px 4px rgba(0, 0, 0, 0.65)",
          fontFamily: fontSrc ?? "sans-serif",
          letterSpacing: 0.5,
        }}
      >
        {message}
      </span>
    </div>
  );
};

/** 数值变化提示界面模块：被主逻辑 show/hide 控制 */
@extension({
  id: "periodic-hint-ui",
  label: "间期变化提示界面",
  description: "因变量变化时显示的顶部提示条，支持自定义字体。",
})
export class PeriodicHintUI extends Extension {
  render() {
    return {
      component: HintOverlay,
      props: this.data ?? {},
    };
  }
}

type DiagProps = { lines?: string[] };

/**
 * 诊断面板：屏幕中央弹出，6 秒后自动关闭，也可点右上角“关闭”按钮手动关闭。
 * 样式：固定使用半透明深色圆角面板（无背景图）。
 */
const DiagOverlay: React.FC<DiagProps> = ({ lines }) => {
  const ctx = useExtensionContext();

  useEffect(() => {
    const timer = setTimeout(() => {
      void ctx.ui.hide("periodic-diag-ui");
    }, 6000);
    return () => clearTimeout(timer);
  }, [ctx, lines]);

  if (!lines || lines.length === 0) return null;

  return (
    <div
      style={{
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        zIndex: 9999,
        width: "min(600px, 86vw)",
        minHeight: 240,
        padding: "48px 38px 34px",
        boxSizing: "border-box",
        background:
          "linear-gradient(180deg, rgba(16, 24, 48, 0.94), rgba(8, 12, 28, 0.96))",
        border: "1px solid rgba(255, 255, 255, 0.18)",
        borderRadius: 18,
        color: "#EAF2FF",
        fontFamily: "ui-monospace, Menlo, Consolas, monospace",
        fontSize: 14,
        lineHeight: 1.75,
        whiteSpace: "pre-wrap",
        pointerEvents: "auto",
        filter: "drop-shadow(0 10px 30px rgba(0, 0, 0, 0.5))",
      }}
    >
      <pre
        style={{
          margin: 0,
          whiteSpace: "pre-wrap",
          wordBreak: "break-all",
          fontFamily: "inherit",
        }}
      >
        {lines.join("\n")}
      </pre>
      <button
        onClick={() => void ctx.ui.hide("periodic-diag-ui")}
        style={{
          position: "absolute",
          right: 16,
          top: 12,
          border: "none",
          background: "rgba(255, 255, 255, 0.16)",
          color: "#fff",
          fontSize: 13,
          padding: "4px 14px",
          borderRadius: 999,
          cursor: "pointer",
        }}
      >
        关闭
      </button>
    </div>
  );
};

/** 诊断界面模块：被「诊断：打印当前状态」方法 show 出来 */
@extension({
  id: "periodic-diag-ui",
  label: "间期诊断界面",
  description: "诊断信息显示面板，使用自定义背景图。",
})
export class PeriodicDiagUI extends Extension {
  render() {
    return {
      component: DiagOverlay,
      props: this.data ?? {},
    };
  }
}

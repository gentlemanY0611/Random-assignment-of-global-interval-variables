import React, { useEffect, useRef, useState } from "react";
import {
  Extension,
  extension,
  method,
  settings,
  useExtensionContext,
  type ExtensionContext,
  type SettingsBuilder,
} from "@avg-studio/sdk";
// 提示条默认背景图（随扩展打包内联；可被手动替换）
import hintBgUrl from "./assets/hint-bg.png";

/* ------------------------------------------------------------------ *
 * 全局间期变量随机赋值v3.1.0（periodic-random-decay-3.1）
 *
 * 功能：注册一条规则后，每当「自变量」推进达到设定的间隔数，
 *       自动把「因变量」随机增加或减少 [下限, 上限] 区间内的一个整数。
 *       - 全局自动触发：插件在引擎启动时挂载全局监听，只要自变量
 *         发生变化（无论来自哪个选项、章节或剧情）都会自动结算，
 *         不受选项等其他因素影响。
 *       - 剧本选项卡中可以直接选择变量：本扩展的剧本方法使用
 *         type: "variable" 参数，在「调用扩展方法」Block 的属性面板里
 *         会出现变量下拉选择器。
 * ------------------------------------------------------------------ */

/* ----------------------------- 数据结构 ----------------------------- */

/** 规则主体（不含数据库生成 id） */
type DecayRuleData = {
  /** 自变量名：表示推进变化的数值变量（如游戏日） */
  dayVariable: string;
  /** 因变量名：需要被周期赋值的数值 */
  targetVariable: string;
  /** 自变量变化数（间隔数）：每经过 N 个间隔结算一次 */
  interval: number;
  /** 随机变化下限（含） */
  minDecrease: number;
  /** 随机变化上限（含） */
  maxDecrease: number;
  /** 上次结算时的自变量值（用于判断是否到期） */
  lastAppliedDay: number;
  /** 变化时是否在游戏中显示提示 */
  showHint: boolean;
  /** 方向：decrease=减少，increase=增加；单因变量模式带 fixed- 前缀 */
  mode:
    | "decrease"
    | "increase"
    | "fixed-decrease"
    | "fixed-increase";
};

/** 数据库中的完整规则记录 */
type DecayRule = DecayRuleData & { id: string };

/** 规则集合的最小操作面（与 ctx.database.collection 返回类型兼容） */
interface RulesCollection {
  find(filter?: unknown): Promise<unknown[]>;
  insertOne(data: Record<string, unknown>): Promise<{ id: string }>;
  updateOne(
    filter: Record<string, unknown>,
    update: Record<string, unknown>,
  ): Promise<unknown>;
  deleteOne(filter: Record<string, unknown>): Promise<unknown>;
}

/* ----------------------------- 工具函数 ----------------------------- */

/** 取 [min, max] 闭区间内的随机整数；非法范围自动纠正为 [0, 大] */
function randomInt(min: number, max: number): number {
  const lo = Math.max(0, Math.min(min, max));
  const hi = Math.max(0, Math.max(min, max));
  if (hi === 0) return 0;
  return Math.floor(Math.random() * (hi - lo + 1)) + lo;
}

/** 获取规则集合（规则持久化在项目数据集合中，随存档保存） */
function rulesCollection(ctx: ExtensionContext): RulesCollection {
  return ctx.database.collection("rules") as unknown as RulesCollection;
}

/* ------------------- 全局结算（核心逻辑，串行执行） ------------------ */

/**
 * 串行队列：variable:changed 可能在一瞬间被触发多次
 * （例如结算时写入因变量也会触发事件），必须保证
 * 结算过程不重叠，否则会出现重复变化。
 */
let tickQueue: Promise<void> = Promise.resolve();

/**
 * 单因变量模式（fixed-*）的全局步进时钟：
 * - 插件结算写入因变量后，引擎会再次触发 variable:changed 回声事件。
 *   若不抑制，interval=1 时「结算 → 事件 → 步进 → 结算」会无限自我循环。
 * - 因此插件每次写入因变量都记录时间戳，200ms 内的回声事件不计步；
 *   用户/剧本的普通操作（间隔通常远大于 200ms）正常计步。
 */
const SELF_WRITE_SUPPRESS_MS = 200;
let lastSelfWriteTs = 0;

/** 单因变量模式规则的当前步数：规则行 id → 已累计的全局变化次数 */
const fixedStepMeta = new Map<string, number>();

/** 判断规则是否为「单因变量模式」（mode 带 fixed- 前缀，编码于数据集合，持久化） */
function isFixedMode(mode: string): boolean {
  return mode === "fixed-increase" || mode === "fixed-decrease";
}

/** 取规则实际操作方向（去掉 fixed- 前缀） */
function fixedAction(mode: string): "increase" | "decrease" {
  return mode === "fixed-increase" ? "increase" : "decrease";
}

function enqueueTick(ctx: ExtensionContext): void {
  tickQueue = tickQueue
    .then(() => processAllRules(ctx))
    .catch((err) => console.warn("[全局间期变量随机赋值v3.1.0]", err));
}

/** 遍历全部规则，逐条结算 */
async function processAllRules(ctx: ExtensionContext): Promise<void> {
  const rules = rulesCollection(ctx);
  const all = ((await rules.find({})) ?? []) as DecayRule[];
  for (const rule of all) {
    await processRule(ctx, rules, rule);
  }
}

/** 结算单条规则（普通模式：受自变量控制；单因变量模式：按全局变化步数） */
async function processRule(
  ctx: ExtensionContext,
  rules: RulesCollection,
  rule: DecayRule,
): Promise<void> {
  // 单因变量模式：因变量不受自变量控制，只按「操作方向 + 间隔数 + 随机值域」周期变化。
  // 推进单位是全局任意变量的变化事件：每收到一次变化计一步，累计达到间隔数 N 结算一次。
  if (isFixedMode(rule.mode)) {
    await processFixedRule(ctx, rules, rule);
    return;
  }

  const day = ctx.variables.get<number>(rule.dayVariable);

  // 自变量还不是数值（未初始化 / 声明类型不对 / 数据损坏）→ 跳过并提示
  if (typeof day !== "number" || !Number.isFinite(day)) {
    console.warn(
      `[全局间期变量随机赋值v3.1.0] 自变量「${rule.dayVariable}」当前不是有效数值，已跳过本次结算。`,
    );
    return;
  }

  // 防御：数据集合被手工编辑成非法值时仍能正常结算
  const interval = Math.max(1, Math.floor(rule.interval) || 1);
  const minD = Number.isFinite(rule.minDecrease) ? rule.minDecrease : 0;
  const maxD = Number.isFinite(rule.maxDecrease) ? rule.maxDecrease : 0;

  // 自变量变化结算：按「变化量绝对值」判断，自变量增加或减少都会触发。
  // last 记录上次结算时的自变量值；|当前值 - last| ≥ 间隔数 N 即结算。
  // （赋值更小、减去某值、除以倍数等使自变量变小的操作同样计入间期。）
  let last = rule.lastAppliedDay;
  if (!Number.isFinite(last)) {
    // 首次运行（无基线）→ 只记录基线，不结算
    last = day;
    await rules.updateOne(
      { id: rule.id },
      { $set: { lastAppliedDay: day } },
    );
    return;
  }

  const elapsed = Math.abs(day - last);
  if (elapsed < interval) return;

  // 扩展设置里的总开关：关闭时只“追平”间隔数、不变化，
  // 避免重新开启后一次性把之前所有周期全部补算。
  const enabled = ctx.settings.get<boolean>("enabled") ?? true;
  if (!enabled) {
    await rules.updateOne(
      { id: rule.id },
      { $set: { lastAppliedDay: day } },
    );
    return;
  }

  // 计算应结算的完整周期数（支持一次跳过多个间隔/多天）
  const times = Math.floor(elapsed / interval);
  let delta = 0;
  for (let i = 0; i < times; i++) {
    delta += randomInt(minD, maxD);
  }
  await applyChange(ctx, rule, delta, times);
}

/** 单因变量模式：按全局变化步数推进（不受自变量数值控制） */
async function processFixedRule(
  ctx: ExtensionContext,
  rules: RulesCollection,
  rule: DecayRule,
): Promise<void> {
  // 抑制窗口：插件刚写入因变量产生的回声事件不计步（防止 interval=1 时自我循环）
  const now = Date.now();
  if (now - lastSelfWriteTs < SELF_WRITE_SUPPRESS_MS) return;

  const interval = Math.max(1, Math.floor(rule.interval) || 1);
  const step = (fixedStepMeta.get(rule.id) ?? 0) + 1;
  if (step < interval) {
    fixedStepMeta.set(rule.id, step);
    return;
  }
  fixedStepMeta.delete(rule.id); // 达到间隔数 → 清零并结算

  const minD = Number.isFinite(rule.minDecrease) ? rule.minDecrease : 0;
  const maxD = Number.isFinite(rule.maxDecrease) ? rule.maxDecrease : 0;
  const delta = randomInt(minD, maxD);
  await applyChange(ctx, rule, delta, 1);
}

/** 写入因变量、更新基线、打印日志、弹提示条（普通/单因变量两种模式共用） */
async function applyChange(
  ctx: ExtensionContext,
  rule: DecayRule,
  delta: number,
  times: number,
): Promise<void> {
  const rules = rulesCollection(ctx);
  const mode = rule.mode === "increase" || rule.mode === "fixed-increase"
    ? "increase"
    : "decrease";
  const current = ctx.variables.get<number>(rule.targetVariable);
  // 减少方向最低扣到 0；增加方向不设上限
  const next = mode === "increase"
    ? (current ?? 0) + delta
    : Math.max(0, (current ?? 0) - delta);
  ctx.variables.set(rule.targetVariable, next);
  lastSelfWriteTs = Date.now(); // 记录写入时间，抑制回声事件计步

  // 普通模式推进基线（单因变量模式无基线，不更新 lastAppliedDay）
  if (!isFixedMode(rule.mode)) {
    const day = ctx.variables.get<number>(rule.dayVariable);
    if (Number.isFinite(day)) {
      await rules.updateOne(
        { id: rule.id },
        { $set: { lastAppliedDay: day } },
      );
    }
  }

  const actionText = mode === "increase" ? "增加" : "减少";
  console.log(
    `[全局间期变量随机赋值v3.1.0] ${rule.targetVariable}：${current ?? 0} → ${next}` +
      `（经过 ${times} 个间隔，共随机${actionText} ${delta}` +
      (isFixedMode(rule.mode)
        ? "，单因变量模式：按全局变化步数推进）"
        : `；自变量基线推进）`),
  );

  if (rule.showHint) {
    // pointerEventsPassthrough：全屏根层不接管指针，提示条显示期间不拦截游戏点击，
    // 点击屏幕可正常推进对话（非模态浮层，仅提示条自身矩形区域可交互）
    void ctx.ui.show(
      "periodic-hint-ui",
      {
        message: `${rule.targetVariable} ${actionText}了 ${delta} 点（当前 ${next}）`,
        actionText,
      },
      { pointerEventsPassthrough: true },
    );
  }
}

/* ------------------------------ 扩展本体 ----------------------------- */

@extension({
  id: "periodic-decay",
  label: "全局间期变量随机赋值v3.1.0",
  description:
    "每经过指定间隔数，自动把因变量的值随机增加或减少一个区间内的数值；全局自动触发，不受选项影响，剧本中可直接选择变量。",
})
export class PeriodicDecay extends Extension {
  /** 项目级设置：总开关 + 提示条自定义（背景/字体/字号/位置/颜色） */
  static settings = settings((s: SettingsBuilder) => ({
    enabled: s.boolean("全局变量间期随机赋值").default(true),
    hintBackground: s
      .asset("提示条背景图（可选）")
      .accepts("image")
      .describe(
        "在素材选择器里选择引擎中已导入的图片（如资产-背景图）作为提示条背景；不设置时使用插件自带默认图（也可手动拖入 src/assets/hint-bg.png 替换后重新构建）。规格：横向宽图，推荐 1024×512（2:1）或更宽，PNG 透明底最佳，重要内容放画面中央（左右边缘会被等比裁切）。",
      ),
    hintFontAsset: s
      .asset("提示条字体（可选）")
      .accepts("any")
      .describe(
        "填写或选择已下载/导入的字体（填字体名列表如 “'Source Han Serif SC', sans-serif”，或以 http/data: 开头的字体文件地址）；不设置时跟随游戏界面默认字体。",
      ),
    hintFontSize: s
      .number("提示条字体大小")
      .default(18)
      .range(0, 38)
      .describe("提示条文字的字号（像素），默认 18，可调范围 0~38。"),
    hintBoxScale: s
      .number("提示条框大小")
      .default(100)
      .range(0, 1000)
      .describe(
        "提示条整体框体的大小比例（相对默认尺寸），可调范围 0~1000，默认 100（原始大小）。改变框大小时，框内字体与背景图会同步等比缩放，但不改变「提示条字体大小」设置项的数值。",
      ),
    hintDuration: s
      .number("提示条显示时长（秒）")
      .default(2.5)
      .range(0, 10000)
      .describe(
        "提示条自动消失的时长（秒），可调范围 0~10000；0 表示立即消失。点击屏幕推进对话也会立即隐藏提示条。",
      ),
    hintAlignX: s
      .enum("提示条屏幕水平位置", ["left", "center", "right"] as const)
      .default("center")
      .labels({ left: "屏幕左侧", center: "屏幕居中", right: "屏幕右侧" })
      .describe("提示条在屏幕上的水平位置：靠左 / 居中 / 靠右（相对整个屏幕），默认居中。"),
    hintAlignY: s
      .enum("提示条屏幕垂直位置", ["top", "center", "bottom"] as const)
      .default("top")
      .labels({ top: "屏幕顶部", center: "屏幕居中", bottom: "屏幕底部" })
      .describe("提示条在屏幕上的垂直位置：顶部 / 居中 / 底部（相对整个屏幕），默认顶部。"),
    hintFreePos: s
      .boolean("自由位置（拖动）")
      .default(false)
      .describe(
        "开启后，可在游戏预览中按住提示条直接在屏幕上拖动到任意位置，松手自动保存；关闭后回到“屏幕水平/垂直位置”设置。",
      ),
    hintFreeX: s
      .number("自由位置 X（%）")
      .default(50)
      .range(0, 100)
      .describe("自由位置模式下提示条在屏幕上的横向位置（百分比，相对屏幕宽度），由拖动自动更新，也可手动微调。"),
    hintFreeY: s
      .number("自由位置 Y（%）")
      .default(20)
      .range(0, 100)
      .describe("自由位置模式下提示条在屏幕上的纵向位置（百分比，相对屏幕高度），由拖动自动更新，也可手动微调。"),
    hintPositionPreview: s
      .boolean("位置预览（常驻显示）")
      .default(false)
      .describe(
        "开启后，提示条在游戏中常驻显示、不自动消失，方便对照调整屏幕水平/垂直/自由位置；关闭后按“提示条显示时长（秒）”设置自动消失。",
      ),
    hintColor: s
      .color("提示条文字颜色")
      .default("#FFFFFF")
      .describe("提示条文字的颜色，默认白色。"),
  }));

  /**
   * 模块级全局钩子：引擎启动时注册一次。
   * 监听所有运行时变量变化，只要「自变量」推进到结算点，
   * 无论玩家走到哪个选项分支，都会自动变化。
   */
  static onRegister(ctx: ExtensionContext): void {
    ctx.subscribe("variable:changed", () => {
      enqueueTick(ctx);
    });
    console.log("[全局间期变量随机赋值v3.1.0] 全局监听已挂载。");

    // 数值设置越界守护：Studio 设置面板的 number 输入不强制范围校验，
    // 订阅 4 个数值设置项，用户一输入越界值（如字体大小 4567）立即写回范围内
    // 最大值/最小值，保证面板显示与运行时数据都回正。
    const guard = (key: string, min: number, max: number) => {
      const clamp = (v: number): number => Math.min(max, Math.max(min, v));
      ctx.settings.subscribe<number>(key, (next) => {
        if (typeof next !== "number" || !Number.isFinite(next)) return;
        const fixed = clamp(next);
        if (fixed !== next) {
          ctx.settings.set(key, fixed);
          console.log(
            `[全局间期变量随机赋值v3.1.0] 设置值越界已回正：${key} → ${fixed}`,
          );
        }
      });
      // 启动时对已存在的越界值也做一次回正
      const cur = ctx.settings.get<number>(key);
      if (typeof cur === "number" && Number.isFinite(cur)) {
        const fixed = clamp(cur);
        if (fixed !== cur) {
          ctx.settings.set(key, fixed);
          console.log(
            `[全局间期变量随机赋值v3.1.0] 设置值越界已回正：${key} → ${fixed}`,
          );
        }
      }
    };
    guard("hintFontSize", 0, 38);
    guard("hintBoxScale", 0, 1000);
    guard("hintDuration", 0, 10000);
    guard("hintFreeX", 0, 100);
    guard("hintFreeY", 0, 100);
    console.log("[全局间期变量随机赋值v3.1.0] 数值设置越界守护已挂载。");
  }

  /** 注册一条全局间期随机赋值规则（可减可加） */
  static registerDecay = method({
    title: "注册全局间期随机赋值",
    description:
      "注册一条规则：从当前自变量（游戏日）的数值起算，每经过 N 个间隔数，因变量（目标数值）的值自动随机增加或减少 [下限, 上限] 区间内的一个整数。规则全局自动触发，不受选项影响。开启「单因变量模式」后，因变量不再受自变量控制，改为按全局变量变化次数推进间隔。",
    schema: {
      dayVariable: {
        type: "variable",
        label: "自变量",
        required: true,
      },
      targetVariable: {
        type: "variable",
        label: "因变量",
        required: true,
      },
      useFixedCadence: {
        type: "boolean",
        label: "单因变量模式（不受自变量控制）",
        default: false,
      },
      mode: {
        type: "enum",
        label: "操作方向",
        options: [
          { value: "decrease", label: "减少" },
          { value: "increase", label: "增加" },
        ],
        default: "decrease",
        required: true,
      },
      interval: {
        type: "number",
        label: "自变量变化数（间隔数）",
        min: 0,
        max: 999999,
        step: 1,
        default: 7,
        required: true,
      },
      minDecrease: {
        type: "number",
        label: "随机变化下限",
        min: 0,
        max: 999999,
        step: 1,
        default: 1,
        required: true,
      },
      maxDecrease: {
        type: "number",
        label: "随机变化上限",
        min: 0,
        max: 999999,
        step: 1,
        default: 5,
        required: true,
      },
      showHint: {
        type: "boolean",
        label: "变化时在游戏中显示提示",
        default: true,
      },
    },
    async run(
      ctx: ExtensionContext,
      params: {
        dayVariable: string;
        targetVariable: string;
        useFixedCadence: boolean;
        mode: "decrease" | "increase";
        interval: number;
        minDecrease: number;
        maxDecrease: number;
        showHint: boolean;
      },
    ): Promise<void> {
      const {
        dayVariable,
        targetVariable,
        useFixedCadence,
        mode,
        interval,
        minDecrease,
        maxDecrease,
        showHint,
      } = params;

      if (minDecrease > maxDecrease) {
        console.warn(
          `[全局间期变量随机赋值v3.1.0] 下限(${minDecrease})大于上限(${maxDecrease})，运行时会自动交换处理。`,
        );
      }

      // 单因变量模式：把模式编码为 fixed-* 前缀存进 mode 列（8 列契约不变），
      // 随存档持久化，重启/读档后模式依然生效。
      const storedMode =
        useFixedCadence === true
          ? (mode === "increase" ? "fixed-increase" : "fixed-decrease")
          : mode;

      const startDay = ctx.variables.get<number>(dayVariable) ?? 0;
      const rules = rulesCollection(ctx);
      const inserted = await rules.insertOne({
        dayVariable,
        targetVariable,
        mode: storedMode,
        interval: Math.max(1, Math.floor(interval)),
        minDecrease,
        maxDecrease,
        lastAppliedDay: startDay,
        showHint,
      });

      const actionText = mode === "increase" ? "增加" : "减少";
      const fixedText = useFixedCadence === true
        ? "（单因变量模式：按全局变量变化次数推进间隔，不受自变量控制）"
        : `（从当前自变量 ${startDay} 起算，增减双向触发）`;
      console.log(
        `[全局间期变量随机赋值v3.1.0] 已注册规则：每 ${interval} 个间隔数，` +
          `「${targetVariable}」随机${actionText} ${minDecrease}~${maxDecrease} 点` +
          fixedText,
      );
    },
  });

  /** 按“自变量 + 因变量”移除已注册的规则 */
  static removeDecay = method({
    title: "移除全局间期随机赋值",
    description:
      "按「自变量 + 因变量」删除已注册的规则，删除后不再自动变化。",
    schema: {
      dayVariable: {
        type: "variable",
        label: "自变量",
        required: true,
      },
      targetVariable: {
        type: "variable",
        label: "因变量",
        required: true,
      },
    },
    async run(
      ctx: ExtensionContext,
      params: { dayVariable: string; targetVariable: string },
    ): Promise<void> {
      const rules = rulesCollection(ctx);
      const matches = ((await rules.find({
        dayVariable: params.dayVariable,
        targetVariable: params.targetVariable,
      })) ?? []) as DecayRule[];
      for (const rule of matches) {
        await rules.deleteOne({ id: rule.id });
      }
      console.log(
        `[全局间期变量随机赋值v3.1.0] 已移除 ${matches.length} 条规则` +
          `（${params.dayVariable} × ${params.targetVariable}）`,
      );
    },
  });

  /** 清空当前存档中的全部规则 */
  static clearAllDecay = method({
    title: "清空全部间期随机赋值规则",
    description: "删除当前存档中注册的全部间期随机赋值规则。",
    async run(ctx: ExtensionContext): Promise<void> {
      const rules = rulesCollection(ctx);
      const all = ((await rules.find({})) ?? []) as DecayRule[];
      for (const rule of all) {
        await rules.deleteOne({ id: rule.id });
      }
      console.log(
        `[全局间期变量随机赋值v3.1.0] 已清空全部 ${all.length} 条规则`,
      );
    },
  });

  /** 诊断方法：在游戏中弹出当前状态，方便排查问题 */
  static diagnose = method({
    title: "诊断：打印当前状态",
    description:
      "在游戏画面顶部弹出当前规则数量、每条规则详情、自变量和因变量的当前值。用于排查为什么变化不生效。",
    async run(ctx: ExtensionContext): Promise<void> {
      const lines: string[] = [];
      lines.push("=== 诊断 ===");

      try {
        const rules = rulesCollection(ctx);
        const all = ((await rules.find({})) ?? []) as DecayRule[];
        lines.push(`规则总数：${all.length}`);
        for (let i = 0; i < all.length; i++) {
          const r = all[i];
          const day = ctx.variables.get<number>(r.dayVariable);
          const target = ctx.variables.get<number>(r.targetVariable);
          lines.push(
            `#${i + 1} 自变量=${r.dayVariable}(${day}) 因变量=${r.targetVariable}(${target}) ` +
            `${isFixedMode(r.mode) ? "单因变量-" : ""}${fixedAction(r.mode) === "increase" ? "加" : "减"} ` +
            `间隔=${r.interval} ${r.minDecrease}~${r.maxDecrease} 上次=${r.lastAppliedDay}`,
          );
        }
      } catch (e) {
        lines.push(`读取规则失败：${String(e)}`);
      }

      console.log("[诊断]\n" + lines.join("\n"));
      void ctx.ui.show("periodic-diag-ui", {
        lines,
      });
    },
  });
}

/* ------------------- 自定义提示 / 诊断界面 ------------------- */

/** 从素材值里尽量提取可显示的地址（兼容字符串与对象两种形态） */
const extractAssetUrl = (v: unknown): string | undefined => {
  if (typeof v === "string") {
    const t = v.trim();
    return t.length > 0 ? t : undefined;
  }
  if (v && typeof v === "object") {
    const o = v as Record<string, unknown>;
    for (const k of ["url", "uri", "src", "path", "source", "assetUrl"]) {
      const val = o[k];
      if (typeof val === "string" && val.trim().length > 0) return val.trim();
    }
    for (const k of ["value", "id"]) {
      const val = o[k];
      if (typeof val === "string" && val.trim().length > 0) return val.trim();
    }
  }
  return undefined;
};

/**
 * 把素材设置值解析为可显示地址。
 * SDK 真实契约：素材设置值 = 素材 URI；ctx.asset.resolve(uri) → AssetRef（含可访问地址）。
 * 优先走 resolve，再对返回对象做常见字段提取；resolve 不可用/失败时退回原始值直接尝试。
 */
const resolveAssetUrl = (
  ctx: ExtensionContext,
  raw: unknown,
): string | undefined => {
  const direct = extractAssetUrl(raw);
  const assetApi = (ctx as unknown as Record<string, unknown>)["asset"] as
    | Record<string, unknown>
    | undefined;
  const resolveFn =
    assetApi && typeof assetApi["resolve"] === "function"
      ? (assetApi["resolve"] as (u: unknown) => unknown)
      : undefined;
  if (resolveFn) {
    try {
      const ref = resolveFn(direct ?? raw);
      console.log(
        "[全局间期变量随机赋值v3.1.0] ctx.asset.resolve 结果：",
        JSON.stringify(ref),
      );
      return extractAssetUrl(ref) ?? direct ?? undefined;
    } catch (err) {
      console.warn(
        "[全局间期变量随机赋值v3.1.0] ctx.asset.resolve 解析失败：",
        err,
      );
      return direct ?? undefined;
    }
  }
  return direct ?? undefined;
};

type HintProps = { message?: string; actionText?: string };

/**
 * 数值变化提示：顶部通栏提示条。
 * 背景：扩展设置里选的引擎素材 > 插件打包默认图（hint-bg.png）。
 * 文字：可选自定义字体 + 颜色。约 2.5 秒后自动关闭。
 */
const HintOverlay: React.FC<HintProps> = ({ message, actionText }) => {
  const ctx = useExtensionContext();
  const [fontReady, setFontReady] = useState(false);
  const [resolvedBg, setResolvedBg] = useState<string | undefined>(undefined);

  // 读取创作者在扩展设置里选的提示条背景图、字体素材与文字颜色
  const rawBg = ctx.settings.cross.get<unknown>(
    "periodic-decay",
    "hintBackground",
  );
  const fontAsset = ctx.settings.cross.get<string>(
    "periodic-decay",
    "hintFontAsset",
  );
  const hintColor = ctx.settings.cross.get<string>(
    "periodic-decay",
    "hintColor",
  );
  const hintFontSize = ctx.settings.cross.get<number>(
    "periodic-decay",
    "hintFontSize",
  );
  const hintBoxScale = ctx.settings.cross.get<number>(
    "periodic-decay",
    "hintBoxScale",
  );
  const hintAlignX = ctx.settings.cross.get<string>(
    "periodic-decay",
    "hintAlignX",
  );
  const hintAlignY = ctx.settings.cross.get<string>(
    "periodic-decay",
    "hintAlignY",
  );
  const hintFreePos = ctx.settings.cross.get<boolean>(
    "periodic-decay",
    "hintFreePos",
  );
  const hintFreeX = ctx.settings.cross.get<number>(
    "periodic-decay",
    "hintFreeX",
  );
  const hintFreeY = ctx.settings.cross.get<number>(
    "periodic-decay",
    "hintFreeY",
  );
  const hintPositionPreview = ctx.settings.cross.get<boolean>(
    "periodic-decay",
    "hintPositionPreview",
  );
  const hintDuration = ctx.settings.cross.get<number>(
    "periodic-decay",
    "hintDuration",
  );

  // 解析提示条背景素材为可显示 URL；未设置时回退插件打包默认图
  useEffect(() => {
    if (!rawBg) return;
    console.log(
      "[全局间期变量随机赋值v3.1.0] 自定义提示条背景原始值：",
      JSON.stringify(rawBg),
    );
    const u = resolveAssetUrl(ctx, rawBg);
    if (u) setResolvedBg(u);
  }, [ctx, rawBg]);

  // 调试用：打印设置里的字体值形态，便于确认是否需要额外解析
  useEffect(() => {
    if (fontAsset) {
      console.log(
        "[全局间期变量随机赋值v3.1.0] 自定义提示条字体值：",
        fontAsset,
      );
    }
  }, [fontAsset]);

  // 判断素材值是否是可直接加载的 URL（http/https/data/blob）
  const isUrlLike = (v: string): boolean =>
    /^(https?:|data:|blob:)/i.test(v.trim());

  // 动态加载所选字体：
  // - 值是 URL（字体文件地址）→ 用 FontFace 动态注册后使用
  // - 值不是 URL（直接填的字体名 / font-family 列表）→ 无需加载，直接作为 fontFamily
  useEffect(() => {
    const fontVal = fontAsset?.trim();
    if (!fontVal) return;
    if (!isUrlLike(fontVal)) return;
    const face = new FontFace("PeriodicHintFont", `url(${fontVal})`);
    face
      .load()
      .then((loaded) => {
        document.fonts.add(loaded);
        setFontReady(true);
      })
      .catch((err) =>
        console.warn("[全局间期变量随机赋值v3.1.0] 提示条字体加载失败：", err),
      );
  }, [fontAsset]);

  // 背景：优先用扩展设置里选的引擎素材（经解析后的 URL）；解析不到时用打包默认图
  const bgSrc = resolvedBg ?? hintBgUrl;

  // 字体显示逻辑：
  // - URL 且加载成功 → 使用动态注册的 PeriodicHintFont
  // - 非 URL（字体名/font-family 列表）→ 直接使用该值
  // - 未设置 → 跟随游戏界面默认字体
  const fontVal = fontAsset?.trim();
  const fontSrc = fontVal
    ? isUrlLike(fontVal)
      ? fontReady
        ? "PeriodicHintFont"
        : undefined
      : fontVal
    : undefined;

  // 数值范围夹取：引擎设置面板不校验 number 输入，运行时统一夹取到设置范围内
  const clampNum = (v: unknown, min: number, max: number, def: number): number => {
    const n = typeof v === "number" && Number.isFinite(v) ? v : def;
    return Math.min(max, Math.max(min, n));
  };

  // 数值越界自动回正：发现设置值超出范围（如字体大小 99）时，写回范围内最大值/最小值，
  // 保证数值固定在范围内，并让下一次设置读取到修正值。
  useEffect(() => {
    const fixes: Array<[string, number]> = [];
    const push = (key: string, raw: unknown, min: number, max: number) => {
      if (typeof raw !== "number" || !Number.isFinite(raw)) return;
      const clamped = Math.min(max, Math.max(min, raw));
      if (clamped !== raw) fixes.push([key, clamped]);
    };
    push("hintFontSize", hintFontSize, 0, 38);
    push("hintBoxScale", hintBoxScale, 0, 1000);
    push("hintDuration", hintDuration, 0, 10000);
    push("hintFreeX", hintFreeX, 0, 100);
    push("hintFreeY", hintFreeY, 0, 100);
    for (const [key, val] of fixes) {
      ctx.settings.cross.set("periodic-decay", key, val);
      console.log(
        `[全局间期变量随机赋值v3.1.0] 设置值越界已回正：${key} → ${val}`,
      );
    }
  }, [ctx, hintFontSize, hintDuration, hintFreeX, hintFreeY]);

  useEffect(() => {
    // 位置预览（常驻显示）开启时不自动关闭，方便对照调整位置
    if (hintPositionPreview === true) return;
    // 自动消失：按「提示条显示时长（秒）」设置，0 表示立即消失（默认 2.5）
    const duration = clampNum(hintDuration, 0, 10000, 2.5);
    const timer = setTimeout(() => {
      void ctx.ui.hide("periodic-hint-ui");
    }, duration * 1000);
    return () => clearTimeout(timer);
  }, [ctx, message, hintPositionPreview, hintDuration]);

  if (!message) return null;

  // 文字颜色：优先用扩展设置里的「提示条文字颜色」，未设置时默认白色
  const textColor = hintColor && hintColor.trim().length > 0 ? hintColor.trim() : "#FFFFFF";
  // 文字字号：按「提示条字体大小」设置，夹取到 0~38 范围（0 即最小字号）
  const textSize = clampNum(hintFontSize, 0, 38, 18);
  // 提示条框大小：0~100，默认 100 = 原始尺寸；框体、框内字体与背景图随该比例
  // 等比缩放，但不改动「提示条字体大小」设置项的数值（渲染时另乘缩放系数）。
  const boxScale = clampNum(hintBoxScale, 0, 1000, 100) / 100;

  // 屏幕级定位（整个提示条相对屏幕）：
  // - 非自由模式：水平 屏幕左侧/居中/右侧 × 垂直 屏幕顶部/居中/底部
  // - 自由模式：直接用保存的屏幕百分比坐标（文字中心 = 位置点）
  const hMap: Record<string, number> = { left: 0, center: 50, right: 100 };
  const vMap: Record<string, number> = { top: 0, center: 50, bottom: 100 };
  const hPct = hMap[hintAlignX ?? "center"] ?? 50;
  const vPct = vMap[hintAlignY ?? "top"] ?? 0;
  const hOff = hPct === 0 ? 16 : hPct === 100 ? -16 : 0;
  const vOff = vPct === 0 ? 16 : vPct === 100 ? -16 : 0;

  // 自由位置（拖动）模式：整个提示条可在屏幕上拖动，位置按“相对屏幕的百分比”保存。
  // 关键设计：提示条容器永远 pointer-events:none（点击穿透，不挡游戏对话）；
  // 自由模式开启时，改用 window 捕获阶段监听指针事件——仅当按下点落在提示条范围内
  // 才拦截并开始拖动；点击提示条之外的屏幕区域会直接放行给游戏，对话可正常继续。
  const containerRef = useRef<HTMLDivElement | null>(null);
  const dragStartRef = useRef<{ px: number; py: number; x: number; y: number } | null>(null);
  const draggingRef = useRef(false);
  const dragXYRef = useRef<{ x: number; y: number } | null>(null);
  const [dragXY, setDragXY] = useState<{ x: number; y: number } | null>(null);
  const freePosEnabled = hintFreePos === true;
  // 自由位置坐标夹取到 0~100%
  const freeX = clampNum(hintFreeX, 0, 100, 50);
  const freeY = clampNum(hintFreeY, 0, 100, 20);
  const curXY = dragXY ?? { x: freeX, y: freeY };

  useEffect(() => {
    dragXYRef.current = dragXY;
  }, [dragXY]);

  const clampPct = (v: number): number => Math.min(100, Math.max(0, v));

  // 提示条 left/top 百分比是相对引擎 UI 根层（定位祖先）的尺寸计算的，
  // 拖动换算必须用同一个基数，否则鼠标位移与提示条移动速度不一致（出现偏差）。
  const getRootRect = (el: HTMLElement | null): DOMRect => {
    const base = (el?.offsetParent as HTMLElement | null) ?? undefined;
    const node = base ?? document.documentElement;
    return node.getBoundingClientRect();
  };

  // 点击屏幕推进对话 → 提示条立即消失（捕获阶段监听，先于游戏层消费事件，最可靠）。
  // - 位置预览（常驻显示）开启时除外，保持常驻方便调位置；
  // - 自由位置拖动保护：自由模式开启且按下点在提示条矩形内 → 不隐藏（交给拖动逻辑）；
  // - 其余任意点击 → 立即隐藏提示条（点击同时穿透给游戏推进对话，互不影响）；
  // - hide 后下一次结算的 show 会照常重新显示，不影响后续提示条。
  useEffect(() => {
    if (hintPositionPreview === true) return;
    const el = containerRef.current;
    const onPointerDown = (e: PointerEvent) => {
      if (freePosEnabled && el) {
        const rect = el.getBoundingClientRect();
        const inside =
          e.clientX >= rect.left &&
          e.clientX <= rect.right &&
          e.clientY >= rect.top &&
          e.clientY <= rect.bottom;
        if (inside) return;
      }
      void ctx.ui.hide("periodic-hint-ui");
    };
    window.addEventListener("pointerdown", onPointerDown, true);
    return () => window.removeEventListener("pointerdown", onPointerDown, true);
  }, [ctx, hintPositionPreview, freePosEnabled]);

  useEffect(() => {
    if (!freePosEnabled) return;
    const el = containerRef.current;
    if (!el) return;

    const onMove = (e: PointerEvent) => {
      if (!draggingRef.current || !dragStartRef.current) return;
      const start = dragStartRef.current;
      // 用提示条定位祖先（引擎 UI 根层）的尺寸做换算基数，与渲染百分比一致，
      // 保证提示条移动与鼠标位移 1:1 同步，无偏移。
      const root = getRootRect(el);
      const nx = clampPct(
        start.x + ((e.clientX - start.px) / Math.max(1, root.width)) * 100,
      );
      const ny = clampPct(
        start.y + ((e.clientY - start.py) / Math.max(1, root.height)) * 100,
      );
      setDragXY({ x: nx, y: ny });
    };

    const onUp = (e: PointerEvent) => {
      if (!draggingRef.current) return;
      e.preventDefault();
      e.stopPropagation();
      draggingRef.current = false;
      dragStartRef.current = null;
      const last = dragXYRef.current;
      if (last) {
        const rx = Math.round(last.x * 10) / 10;
        const ry = Math.round(last.y * 10) / 10;
        ctx.settings.cross.set("periodic-decay", "hintFreeX", rx);
        ctx.settings.cross.set("periodic-decay", "hintFreeY", ry);
        console.log(
          `[全局间期变量随机赋值v3.1.0] 提示条自由位置已保存：X=${rx}% Y=${ry}%（相对屏幕）`,
        );
      }
      setDragXY(null);
    };

    const onDown = (e: PointerEvent) => {
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const inside =
        e.clientX >= rect.left &&
        e.clientX <= rect.right &&
        e.clientY >= rect.top &&
        e.clientY <= rect.bottom;
      // 按下点不在提示条内 → 不拦截，点击穿透给游戏（对话可继续）
      if (!inside) return;
      e.preventDefault();
      e.stopPropagation();
      dragStartRef.current = {
        px: e.clientX,
        py: e.clientY,
        x: curXY.x,
        y: curXY.y,
      };
      draggingRef.current = true;
    };

    window.addEventListener("pointerdown", onDown, true);
    window.addEventListener("pointermove", onMove, true);
    window.addEventListener("pointerup", onUp, true);
    window.addEventListener("pointercancel", onUp, true);
    return () => {
      window.removeEventListener("pointerdown", onDown, true);
      window.removeEventListener("pointermove", onMove, true);
      window.removeEventListener("pointerup", onUp, true);
      window.removeEventListener("pointercancel", onUp, true);
    };
  }, [freePosEnabled, curXY.x, curXY.y]);

  // 提示条锚点样式：自由模式用屏幕百分比坐标；否则按屏幕水平/垂直对齐计算
  const anchorStyle = freePosEnabled
    ? {
        left: `${curXY.x}%`,
        top: `${curXY.y}%`,
        transform: "translate(-50%, -50%)",
      }
    : {
        left: `${hPct}%`,
        top: `${vPct}%`,
        transform: `translate(calc(${-hPct}% + ${hOff}px), calc(${-vPct}% + ${vOff}px))`,
      };

  return (
    <div
      ref={containerRef}
      style={{
        position: "absolute",
        ...anchorStyle,
        zIndex: 9999,
        // 框大小：默认 100 = 原始尺寸，随「提示条框大小」等比缩放
        width: `calc(min(720px, 88vw) * ${boxScale})`,
        height: 68 * boxScale,
        backgroundImage: `url(${bgSrc})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        // 始终点击穿透：提示条显示期间不拦截游戏点击，对话可正常推进
        pointerEvents: "none",
        userSelect: "none",
        filter: "drop-shadow(0 6px 16px rgba(0, 0, 0, 0.45))",
      }}
    >
      <span
        style={{
          // 字体随框大小等比缩放（不影响「提示条字体大小」设置数值）
          fontSize: textSize * boxScale,
          fontWeight: 700,
          color: textColor,
          textShadow: "0 2px 4px rgba(0, 0, 0, 0.65)",
          fontFamily: fontSrc ?? "sans-serif",
          letterSpacing: 0.5,
        }}
      >
        {message}
      </span>
    </div>
  );
};

/** 数值变化提示界面模块：被主逻辑 show/hide 控制 */
@extension({
  id: "periodic-hint-ui",
  label: "间期变化提示界面",
  description: "因变量变化时显示的顶部提示条，支持自定义字体。",
})
export class PeriodicHintUI extends Extension {
  render() {
    return {
      component: HintOverlay,
      props: this.data ?? {},
    };
  }
}

type DiagProps = { lines?: string[] };

/**
 * 诊断面板：屏幕中央弹出，6 秒后自动关闭，也可点右上角“关闭”按钮手动关闭。
 * 样式：固定使用半透明深色圆角面板（无背景图）。
 */
const DiagOverlay: React.FC<DiagProps> = ({ lines }) => {
  const ctx = useExtensionContext();

  useEffect(() => {
    const timer = setTimeout(() => {
      void ctx.ui.hide("periodic-diag-ui");
    }, 6000);
    return () => clearTimeout(timer);
  }, [ctx, lines]);

  if (!lines || lines.length === 0) return null;

  return (
    <div
      style={{
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        zIndex: 9999,
        width: "min(600px, 86vw)",
        minHeight: 240,
        padding: "48px 38px 34px",
        boxSizing: "border-box",
        background:
          "linear-gradient(180deg, rgba(16, 24, 48, 0.94), rgba(8, 12, 28, 0.96))",
        border: "1px solid rgba(255, 255, 255, 0.18)",
        borderRadius: 18,
        color: "#EAF2FF",
        fontFamily: "ui-monospace, Menlo, Consolas, monospace",
        fontSize: 14,
        lineHeight: 1.75,
        whiteSpace: "pre-wrap",
        pointerEvents: "auto",
        filter: "drop-shadow(0 10px 30px rgba(0, 0, 0, 0.5))",
      }}
    >
      <pre
        style={{
          margin: 0,
          whiteSpace: "pre-wrap",
          wordBreak: "break-all",
          fontFamily: "inherit",
        }}
      >
        {lines.join("\n")}
      </pre>
      <button
        onClick={() => void ctx.ui.hide("periodic-diag-ui")}
        style={{
          position: "absolute",
          right: 16,
          top: 12,
          border: "none",
          background: "rgba(255, 255, 255, 0.16)",
          color: "#fff",
          fontSize: 13,
          padding: "4px 14px",
          borderRadius: 999,
          cursor: "pointer",
        }}
      >
        关闭
      </button>
    </div>
  );
};

/** 诊断界面模块：被「诊断：打印当前状态」方法 show 出来 */
@extension({
  id: "periodic-diag-ui",
  label: "间期诊断界面",
  description: "诊断信息显示面板，使用自定义背景图。",
})
export class PeriodicDiagUI extends Extension {
  render() {
    return {
      component: DiagOverlay,
      props: this.data ?? {},
    };
  }
}
